"""Ray S3 Module."""
